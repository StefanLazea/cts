package teste.categorii;

public interface CategorieTesteAgentieTurism {

}
