package teste.categorii;

public interface CategorieTestePersoaneVarstnice {

}
