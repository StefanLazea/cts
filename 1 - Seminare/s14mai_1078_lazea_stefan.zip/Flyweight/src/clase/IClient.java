package clase;

public interface IClient {
	void printareReteta(Reteta reteta);
}
