package clase;

public interface ISpital {
	void interneaza(Pacient p);
	void descriere();
}
