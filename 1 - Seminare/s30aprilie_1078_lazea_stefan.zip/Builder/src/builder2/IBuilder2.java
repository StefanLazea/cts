package builder2;

import clase.Rezervare;

public interface IBuilder2 {
	public Rezervare build();
}
