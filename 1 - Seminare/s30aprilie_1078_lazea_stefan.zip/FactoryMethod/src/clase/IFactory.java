package clase;

public interface IFactory {
	public ISupa creareSupa();
}
