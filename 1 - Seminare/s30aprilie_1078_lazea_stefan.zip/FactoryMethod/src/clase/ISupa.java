package clase;

public interface ISupa {
	public void descirere();

}
