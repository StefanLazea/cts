package clase;

public enum TipSupa {
	SupaLegume,
	SupaVita,
	SupaCiuperci
}
