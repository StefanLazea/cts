package exceptii;

public class CnpIsNullException extends IllegalArgumentException{

	public CnpIsNullException(String mesaj) {
		super(mesaj);
	}
}
