package teste.categorii;

public class CategorieTestePersoaneTinere {

}
