package teste.categorii;

public class CategorieTestePersoaneVarstnice {

}
