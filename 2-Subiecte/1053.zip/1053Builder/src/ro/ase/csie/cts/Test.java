package ro.ase.csie.cts;

import ro.ase.csie.cts.hero.HeroBuilder;
import ro.ase.csie.cts.hero.SuperHero;

public class Test {

	public static void main(String[] args) {
		SuperHero hero1 = new HeroBuilder("SuperMan", 100)
		.setAble2Fly()
		.setAge(23)
		.build();
	}

}
