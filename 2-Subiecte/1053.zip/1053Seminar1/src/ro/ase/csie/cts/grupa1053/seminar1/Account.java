package ro.ase.csie.cts.grupa1053.seminar1;

public abstract class Account {
	protected String name;
	protected boolean isActive;
	
	public String getName(){
		return this.name;
	}
	public boolean isActive(){
		return this.isActive;
	}
	
	public abstract void setName(String name);
	public abstract void setActive();
	public abstract void setInactive();
}
