package ro.ase.csie.cts.grupa1053.seminar1;

public abstract class BankAccount extends Account{
	public static final double MAXIMUM_LIMIT = 10000;
	protected double balance;
}
