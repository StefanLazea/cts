package ro.ase.csie.cts.grupa1053.seminar1;

public class Test {
	public static void main(String[] args) {

	}

}
