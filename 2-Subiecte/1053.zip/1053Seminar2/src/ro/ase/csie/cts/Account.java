package ro.ase.csie.cts;

public abstract class Account {
	public abstract void Deposit(double amount);
	public abstract void Withdraw(double amount) throws InsufficientFundsException;
	public abstract void Transfer(Account destination, double amount) 
			throws IllegalTransferException, InsufficientFundsException;
	public abstract double getBalance();
}
