package ro.ase.csie.cts;

public abstract class BankAccount extends Account{
	protected double balance;
	protected String id;
	
	@Override
	public String toString(){
		return "BankAccount "+this.id+": "+this.balance;
	}
	
	
	@Override
	public double getBalance(){
		return this.balance;
	}
	
	@Override
	public void Deposit(double amount){
		this.balance+=amount;
	}
	
}
