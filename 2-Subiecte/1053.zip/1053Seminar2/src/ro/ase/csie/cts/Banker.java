package ro.ase.csie.cts;

public class Banker {
	private static Banker self;
	private static int nextId = 0;
	private static final String bank = "ROBCR";
	
	private Banker(){
		
	}
	public static Banker getBanker(){
		if(Banker.self == null)
			Banker.self = new Banker();
		return Banker.self;
	}
	
	public BankAccount OpenAccount(AccountTypes type){
		Banker.nextId++;
		String accountName = Banker.bank+Banker.nextId;
		
		BankAccount account = null;
		
		switch(type){
		case SAVINGS:
			account = new SavingsAccount(accountName);
			break;
		case CURRENT:
			account = new CurrentAccount(accountName);
			break;
		}
		return account;
	}
	
}

enum AccountTypes {SAVINGS,CURRENT};

