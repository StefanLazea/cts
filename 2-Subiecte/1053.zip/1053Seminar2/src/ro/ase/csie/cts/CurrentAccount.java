package ro.ase.csie.cts;

public class CurrentAccount extends BankAccount{

	public static final double MAX_CREDIT = 5000;
	
	public CurrentAccount(String accountName) {
		this.id = accountName;
		this.balance = CurrentAccount.MAX_CREDIT;
	}

	@Override
	public void Withdraw(double amount) throws InsufficientFundsException {
		if(this.balance < amount)
			throw new InsufficientFundsException("Fonduri insuficiente");
		else
			this.balance-=amount;
	}

	@Override
	public void Transfer(Account destination, double amount) 
			throws IllegalTransferException, InsufficientFundsException {
		BankAccount destAccount = null;
		if(destination instanceof BankAccount)
			destAccount = (BankAccount)destination;
		else
			throw new IllegalTransferException("Strange Account");
		
		if(this.id.equals(destAccount.id))
			throw new IllegalTransferException("Same accounts");
		
		if(destination instanceof CurrentAccount)
			throw new IllegalTransferException("Credit Account");
		
		if(this.balance < amount)
			throw new InsufficientFundsException("No more money");
		else
		{
			this.Withdraw(amount);
			destination.Deposit(amount);
		}
			
	}

}
