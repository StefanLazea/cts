package ro.ase.csie.cts;

public class SavingsAccount extends BankAccount implements Profitable{

	public static final double MIN_BALANCE = 100;
	public SavingsAccount(String accountName) {
		this.id = accountName;
		this.balance = SavingsAccount.MIN_BALANCE;
	}

	@Override
	public void AddInterest(double interest) {
		this.balance*=(1+interest);
	}

	@Override
	public void Withdraw(double amount) throws InsufficientFundsException {
		if((this.balance-SavingsAccount.MIN_BALANCE)<amount)
			throw new InsufficientFundsException(SavingsAccount.class+": MIN_BAlANCE error");
		this.balance-=amount;
	}

	@Override
	public void Transfer(Account destination, double amount)
			throws IllegalTransferException, InsufficientFundsException {
		if(destination == this)
			throw new IllegalTransferException("Same destination");
		if(this.balance-SavingsAccount.MIN_BALANCE < amount)
			throw new InsufficientFundsException("No more money!");
		this.Withdraw(amount);
		destination.Deposit(amount);
	}
	
}
