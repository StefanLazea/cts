package ro.ase.csie.cts;

public class Test {

	public static void main(String[] args) {
		Banker b1 = Banker.getBanker();
		Banker b2 = Banker.getBanker();
		//Banker b3 = new Banker();
		if(b1 == b2)
			System.out.println("Acelasi obiect");
		
		try{
			
			SavingsAccount sa1 = (SavingsAccount)
					b1.OpenAccount(AccountTypes.SAVINGS);
			sa1.Deposit(1000);
			CurrentAccount ca1 = (CurrentAccount)
					b2.OpenAccount(AccountTypes.CURRENT);
			ca1.Withdraw(1000);
			sa1.Transfer(ca1, 500);
			
			System.out.println(sa1);
			System.out.println(ca1);
			
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
		
	}

}
