package ro.ase.csie.cts;

import javax.activation.UnsupportedDataTypeException;

import ro.ase.csie.cts.gadgets.AerConditionat;
import ro.ase.csie.cts.gadgets.AppleTV;
import ro.ase.csie.cts.gadgets.Ferestre;
import ro.ase.csie.cts.gadgets.InterfataGadgetGoogle;
import ro.ase.csie.cts.gadgets.ReteaElectrica;
import ro.ase.csie.cts.gadgets.SenzorTemperatura;
import ro.ase.csie.patterns.AdaptorGadgetApple2Google;
import ro.ase.csie.patterns.DecoratorAerConditionat;
import ro.ase.csie.patterns.SmartHomeFacade;

public class Test {
	public static void main(String[] args) throws UnsupportedDataTypeException{
/*		ReteaElectrica retea = new ReteaElectrica();
		retea.deschide();
		Computer computer = new Computer();
		computer.connect2Internet("10.10.10.1");
		int temperatura = 25;
		SenzorTemperatura senzor = new SenzorTemperatura();
		if(senzor.getTemperatura()>temperatura)
		{
			AerConditionat aer = new AerConditionat();
			aer.porneste(temperatura);
		}
		Ferestre controlFerestre = new Ferestre();
		String[] ferestre = controlFerestre.getFerestre();
		for(String fereastra : ferestre)
			controlFerestre.inchideFereastra(fereastra);	*/
		
		InterfataGadgetGoogle[] gadgets = 
			{
				new AerConditionat(),
				new Ferestre(),
				new ReteaElectrica(),
				new SenzorTemperatura(),
				new AdaptorGadgetApple2Google(new AppleTV())
			};
		
		SmartHomeFacade smartHome = new SmartHomeFacade();
		smartHome.getStatus(gadgets);
		smartHome.pregatesteCasa(25, "10.10.10.1");
		
		//testare decorator
		Ferestre ferestre = new Ferestre();
		ferestre.inchideFereastra("BUCATARIE");
		
		DecoratorAerConditionat ferestreCuAerConditionat = 
				new DecoratorAerConditionat(ferestre);
		
		//inlocuire gadget ferestre cu versiunea imbunatatita - decorata
		gadgets[1] = ferestreCuAerConditionat;
		
		AerConditionat aerConditionat = new AerConditionat();
		aerConditionat.porneste(27);
		
		ferestre.deschideFereastra("BUCATARIE");
		ferestreCuAerConditionat.controleazaAltGadget(aerConditionat);
		
	}
}
