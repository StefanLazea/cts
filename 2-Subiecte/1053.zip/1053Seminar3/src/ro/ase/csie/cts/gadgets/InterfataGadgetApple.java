package ro.ase.csie.cts.gadgets;

public interface InterfataGadgetApple {
	public abstract int getStatus();
}
