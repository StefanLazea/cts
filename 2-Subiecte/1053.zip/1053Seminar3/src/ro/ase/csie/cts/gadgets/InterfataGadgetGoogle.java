package ro.ase.csie.cts.gadgets;

public interface InterfataGadgetGoogle {
	public abstract boolean isWorking();
}
