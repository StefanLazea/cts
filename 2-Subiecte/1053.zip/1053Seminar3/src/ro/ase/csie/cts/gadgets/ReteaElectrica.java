package ro.ase.csie.cts.gadgets;

public class ReteaElectrica implements InterfataGadgetGoogle{
	public void inchide(){
		System.out.println("Retea electrica oprita");
	}
	public void deschide(){
		System.out.println("Retea electrica deschisa");
	}
	@Override
	public boolean isWorking() {
		System.out.println("Reteaua electrica functioneaza");
		return true;
	}
}
