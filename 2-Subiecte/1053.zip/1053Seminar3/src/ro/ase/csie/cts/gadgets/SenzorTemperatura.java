package ro.ase.csie.cts.gadgets;

import java.util.Random;

public class SenzorTemperatura implements InterfataGadgetGoogle{
	public int getTemperatura(){
		Random rand = new Random();
		return rand.nextInt(40);
	}

	@Override
	public boolean isWorking() {
		System.out.println("Senzorul de temperatura functioneaza");
		return true;
	}
	
}
