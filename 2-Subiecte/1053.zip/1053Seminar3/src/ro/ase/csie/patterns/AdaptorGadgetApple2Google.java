package ro.ase.csie.patterns;

import ro.ase.csie.cts.gadgets.InterfataGadgetApple;
import ro.ase.csie.cts.gadgets.InterfataGadgetGoogle;

public class AdaptorGadgetApple2Google implements InterfataGadgetGoogle{

	InterfataGadgetApple gadget;
	
	public AdaptorGadgetApple2Google(
			InterfataGadgetApple deviceApple)
	{
		this.gadget = deviceApple;
	}
	@Override
	public boolean isWorking() {
		if(gadget.getStatus()!=0)
			return true;
		return false;
	}

}
