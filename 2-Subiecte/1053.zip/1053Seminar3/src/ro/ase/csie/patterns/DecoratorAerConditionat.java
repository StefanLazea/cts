package ro.ase.csie.patterns;

import javax.activation.UnsupportedDataTypeException;

import ro.ase.csie.cts.gadgets.AerConditionat;
import ro.ase.csie.cts.gadgets.InterfataGadgetGoogle;

public class DecoratorAerConditionat 
extends DecoratorGadgetGoogle{

	public DecoratorAerConditionat(
			InterfataGadgetGoogle gadget){
		super(gadget);
	}

	@Override
	public void controleazaAltGadget(InterfataGadgetGoogle altGadget) 
			throws UnsupportedDataTypeException {
		if(altGadget instanceof AerConditionat)
			((AerConditionat)altGadget).opreste();
		else
			throw new UnsupportedDataTypeException("AerConditionat");
	}

	@Override
	public boolean isWorking() {
		return this.gadget.isWorking();
	}
}
