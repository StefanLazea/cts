package ro.ase.csie.patterns;

import javax.activation.UnsupportedDataTypeException;

import ro.ase.csie.cts.gadgets.InterfataGadgetGoogle;

public abstract class DecoratorGadgetGoogle 
	implements InterfataGadgetGoogle{
	InterfataGadgetGoogle gadget = null;
	
	public DecoratorGadgetGoogle(InterfataGadgetGoogle gadget){
		this.gadget = gadget;
	}
	
	//metoda abstracta pentru decorare
	public abstract void controleazaAltGadget(
			InterfataGadgetGoogle altGadget) throws UnsupportedDataTypeException;
	
}
