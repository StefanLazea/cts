package ro.ase.csie.cts;

import java.util.List;

public abstract class Angajat {
	public String nume;
	public int varsta;
	
	public abstract String getDescriere();
	public abstract void addSubaltern(Angajat a);
	public abstract void removeSubaltern(Angajat a);
	public abstract List<Angajat> getSubalterni();
	
}
