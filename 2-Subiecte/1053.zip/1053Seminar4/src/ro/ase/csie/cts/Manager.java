package ro.ase.csie.cts;

import java.util.ArrayList;
import java.util.List;

public class Manager extends Angajat{

	ArrayList<Angajat> subalterni;
	
	public Manager(){
		subalterni = new ArrayList<>();
	}
	
	@Override
	public String getDescriere() {
		StringBuilder sb = new StringBuilder();
		sb.append(nume + " - Manager \n");
		if(this.subalterni != null)
			for(Angajat subaltern : subalterni)
				sb.append("\t " + subaltern.getDescriere());
		return sb.toString();
	}

	@Override
	public void addSubaltern(Angajat a) {
		this.subalterni.add(a);
	}

	@Override
	public void removeSubaltern(Angajat a) {
		this.subalterni.remove(a);
	}

	@Override
	public List<Angajat> getSubalterni() {
		return this.subalterni;
	}
	
	
}
