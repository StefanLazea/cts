package ro.ase.csie.cts;

import java.util.List;

public class SimpluAngajat extends Angajat{

	@Override
	public String getDescriere() {
		return this.nume + " - simplu angajat ";
	}

	@Override
	public void addSubaltern(Angajat a) {
		throw new UnsupportedOperationException();
	}

	@Override
	public void removeSubaltern(Angajat a) {
		throw new UnsupportedOperationException();
	}

	@Override
	public List<Angajat> getSubalterni() {
		throw new UnsupportedOperationException();
	}
	
}
