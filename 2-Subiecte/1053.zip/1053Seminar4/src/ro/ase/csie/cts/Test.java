package ro.ase.csie.cts;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Angajat CEO = new Manager();
		Angajat gigel = new Manager();
		Angajat popescu = new SimpluAngajat();
		Angajat ana = new SimpluAngajat();
		gigel.addSubaltern(popescu);
		gigel.addSubaltern(ana);
		CEO.addSubaltern(gigel);
		
	}

}
