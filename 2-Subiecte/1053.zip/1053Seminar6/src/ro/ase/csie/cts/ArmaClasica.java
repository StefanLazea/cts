package ro.ase.csie.cts;

public class ArmaClasica implements TipArma{

	@Override
	public void animatieArma() {
		System.out.println("Pew Pew Pew");
	}

}
