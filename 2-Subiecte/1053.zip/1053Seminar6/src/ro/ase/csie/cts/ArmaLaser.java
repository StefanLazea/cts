package ro.ase.csie.cts;

public class ArmaLaser implements TipArma{

	@Override
	public void animatieArma() {
		System.out.println("-------------------------------------");
	}

}
