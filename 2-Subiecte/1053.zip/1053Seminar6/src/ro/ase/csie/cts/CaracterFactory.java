package ro.ase.csie.cts;

import java.util.HashMap;

//flyweight factory
public class CaracterFactory {
	private HashMap<String,CaracterSoldat> colectieModele = 
			new HashMap<>();
	public CaracterSoldat getModel(String tip){
		CaracterSoldat model = colectieModele.get(tip);
		if(model == null && tip.equals("soldat"))
		{
			model = new Model3DSoldat();
			colectieModele.put("soldat", model);
		}
		if(model == null && tip.equals("comandant")){
			model = new Model3DComandant();
			colectieModele.put("comandant",model);
		}
		return model;
	}
}
