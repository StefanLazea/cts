package ro.ase.csie.cts;


//interfata pentru flyweight
public abstract class CaracterSoldat {
	public String nume;
	
	//referinta catre arma
	protected TipArma arma;
	
	public void setArma(TipArma arma){
		this.arma = arma;
	}
	
	public abstract void merge();
	public abstract void trage();
}
