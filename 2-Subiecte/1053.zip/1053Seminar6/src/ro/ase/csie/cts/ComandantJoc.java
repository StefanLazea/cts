package ro.ase.csie.cts;

public class ComandantJoc extends CaracterSoldat{

	Locatie pozitieHarta;
	TipPozitie pozitie;
	
	public ComandantJoc(String nume, Locatie locatie, TipPozitie pozitie){
		this.nume = nume;
		this.pozitie = pozitie;
		this.pozitieHarta = locatie;
	}
	@Override
	public void merge() {
		System.out.println(" Comandantul " + this.nume+" merge ");
	}

	@Override
	public void trage() {
		System.out.println("Comandantul "+this.nume+" trage cu arma");
		this.arma.animatieArma();
	}

}
