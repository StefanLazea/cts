package ro.ase.csie.cts;

public class Locatie {
	public int X;
	public int Y;
	
	public Locatie(int x, int y){
		this.X = x;
		this.Y = y;
	}
}
