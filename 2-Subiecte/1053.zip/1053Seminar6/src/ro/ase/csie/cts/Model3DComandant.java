package ro.ase.csie.cts;

public class Model3DComandant extends CaracterSoldat{

	//datele comune tuturor clonelor
	byte[]  model3D;
	
	public Model3DComandant(){
		this.nume="Comandant0";
		this.model3D = new byte[2048];
	}
	
	@Override
	public void merge() {
		throw new UnsupportedOperationException();
	}

	@Override
	public void trage() {
		throw new UnsupportedOperationException();
	}

}
