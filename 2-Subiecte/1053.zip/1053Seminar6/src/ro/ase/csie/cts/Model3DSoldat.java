package ro.ase.csie.cts;

public class Model3DSoldat extends CaracterSoldat{

	//datele comune tuturor clonelor
	byte[]  model3D;
	
	public Model3DSoldat(){
		this.nume="Clona0";
		this.model3D = new byte[1024];
	}
	
	@Override
	public void merge() {
		throw new UnsupportedOperationException();
	}

	@Override
	public void trage() {
		throw new UnsupportedOperationException();
	}

}
