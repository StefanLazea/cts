package ro.ase.csie.cts;

public class SoldatJoc extends CaracterSoldat{

	Locatie pozitieHarta;
	TipPozitie pozitie;
	
	public SoldatJoc(String nume, Locatie locatie, TipPozitie pozitie){
		this.nume = nume;
		this.pozitie = pozitie;
		this.pozitieHarta = locatie;
	}
	@Override
	public void merge() {
		System.out.println(" Soldatul merge ");
	}

	@Override
	public void trage() {
		System.out.println("Soldatul "+this.nume+" trage cu arma");
		this.arma.animatieArma();
	}

}
