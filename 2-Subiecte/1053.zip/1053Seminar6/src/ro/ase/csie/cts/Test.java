package ro.ase.csie.cts;

import java.util.ArrayList;

import javax.xml.parsers.FactoryConfigurationError;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		CaracterFactory factory = new CaracterFactory();
		
		//generez soldati si comandanti
		ArrayList<CaracterSoldat> listaCaractereHarta = 
				new ArrayList<CaracterSoldat>();
		ArrayList<CaracterSoldat> referinteModele3D = 
				new ArrayList<>();
				
		SoldatJoc soldat1 = new SoldatJoc("Gigel",
				new Locatie(10, 10), TipPozitie.IN_PICIOARE);
		soldat1.setArma(new ArmaLaser());
		
		listaCaractereHarta.add(soldat1);
		referinteModele3D.add(factory.getModel("soldat"));
		
		SoldatJoc soldat2 = new SoldatJoc("Ion",
				new Locatie(20, 15), TipPozitie.CULCAT);
		soldat2.setArma(new ArmaClasica());
		
		listaCaractereHarta.add(soldat2);
		referinteModele3D.add(factory.getModel("soldat"));
		
		ComandantJoc comandant1 = 
				new ComandantJoc("Popescu", 
						new Locatie(16,20), TipPozitie.IN_PICIOARE);
		comandant1.setArma(new ArmaLaser());
		
		listaCaractereHarta.add(comandant1);
		referinteModele3D.add(factory.getModel("comandant"));
		
		soldat2.trage();
		soldat2.merge();
		soldat2.setArma(new ArmaLaser());
		
		for(int i = 0;i< listaCaractereHarta.size(); i++){
			//desenare harta
			if(listaCaractereHarta.get(i) instanceof SoldatJoc){
				SoldatJoc soldat = (SoldatJoc) listaCaractereHarta.get(i);
				Locatie locatie = soldat.pozitieHarta;
				byte[] bitmap = 
						((Model3DSoldat)referinteModele3D.get(i)).model3D;
			}
			listaCaractereHarta.get(i).trage();
		}
	}

}
