package ro.ase.csie.cts;

public interface TipArma {
	public void animatieArma();
}
