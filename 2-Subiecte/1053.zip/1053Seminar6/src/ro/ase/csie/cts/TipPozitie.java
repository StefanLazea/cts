package ro.ase.csie.cts;

public enum TipPozitie {
	CULCAT,
	IN_PICIOARE,
	IN_GENUNCHI
}
