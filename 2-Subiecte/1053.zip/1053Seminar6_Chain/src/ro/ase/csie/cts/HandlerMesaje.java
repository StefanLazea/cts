package ro.ase.csie.cts;

public abstract class HandlerMesaje {
	HandlerMesaje nextHandler;
	
	public abstract void proceseazaMesaj(Mesaj mesaj);
}
