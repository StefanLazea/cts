package ro.ase.csie.cts;

public class HandlerPrioritateMaxima extends HandlerMesaje{

	@Override
	public void proceseazaMesaj(Mesaj mesaj) {
		//implementare logica handler prioritate maxima
		if(mesaj.prioritate >= 1000)
			System.out.println(
					"Mesaj procesat de HandlerPrioritateMaxima: " + mesaj.text);
		else
			if(mesaj.prioritate <1000 & mesaj.prioritate >= 500){
				System.out.println(
						"Mesaj procesat de HandlerPrioritateMaxima: " + mesaj.text);
				if(nextHandler!=null)
					nextHandler.proceseazaMesaj(mesaj);
			}
			else
				if(nextHandler!=null)
					nextHandler.proceseazaMesaj(mesaj);
	}

}
