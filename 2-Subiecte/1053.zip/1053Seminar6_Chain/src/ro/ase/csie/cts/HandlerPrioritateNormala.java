package ro.ase.csie.cts;

public class HandlerPrioritateNormala extends HandlerMesaje{

	@Override
	public void proceseazaMesaj(Mesaj mesaj) {
		if(mesaj.prioritate > 200)
			System.out.println("Mesaj normal: "+mesaj.text);
		else
			if(nextHandler!=null)
				nextHandler.proceseazaMesaj(mesaj);
	}

}
