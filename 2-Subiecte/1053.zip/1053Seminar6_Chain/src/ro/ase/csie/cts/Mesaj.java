package ro.ase.csie.cts;

public class Mesaj {
	public String text;
	public int prioritate;
	
	public Mesaj(String mesaj, int prioritate){
		this.text = mesaj;
		this.prioritate = prioritate;
	}
}
