package ro.ase.csie.cts;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Mesaj mesaj1= new Mesaj("Ana are mere !", 1001);
		Mesaj mesaj2= new Mesaj("Gigel are mere !", 567);
		Mesaj mesaj3= new Mesaj("Ion are mere !", 400);
		
		HandlerPrioritateMaxima h1 = new HandlerPrioritateMaxima();
		HandlerPrioritateNormala h2 = new HandlerPrioritateNormala();
		
		h1.nextHandler = h2;
		
		//procesare mesaje
		h1.proceseazaMesaj(mesaj1);
		h1.proceseazaMesaj(mesaj2);
		h1.proceseazaMesaj(mesaj3);
	}

}
