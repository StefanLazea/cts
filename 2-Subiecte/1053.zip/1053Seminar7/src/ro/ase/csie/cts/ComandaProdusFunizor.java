package ro.ase.csie.cts;

public class ComandaProdusFunizor extends ComandaProdusOnline{

	@Override
	public void proceseaza(ServiciuLivrareComenzi srv) {
		srv.proceseazaComandaFurnizor(this);
	}

}
