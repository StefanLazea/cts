package ro.ase.csie.cts;

public abstract class ComandaProdusOnline {
	String produs;
	String furnizor;
	public abstract void proceseaza(ServiciuLivrareComenzi srv);
}
