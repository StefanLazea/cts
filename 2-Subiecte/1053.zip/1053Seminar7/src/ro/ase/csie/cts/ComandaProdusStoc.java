package ro.ase.csie.cts;

public class ComandaProdusStoc extends ComandaProdusOnline{

	@Override
	public void proceseaza(ServiciuLivrareComenzi srv) {
		srv.proceseazaComandaStoc(this);
	}

}




