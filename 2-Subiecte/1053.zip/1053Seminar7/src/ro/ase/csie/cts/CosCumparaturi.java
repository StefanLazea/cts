package ro.ase.csie.cts;

import java.util.ArrayList;

public class CosCumparaturi {
	//colectia de comenzi realizate - generate pe baza selectiei de produse
	ArrayList<ComandaProdusOnline> produse;
	String numeUtilizator;
	
	public CosCumparaturi(String utilizator){
		this.produse = new ArrayList<ComandaProdusOnline>();
		this.numeUtilizator = utilizator;
	}
	
	public void adaugaProdus(ComandaProdusOnline comanda){
		this.produse.add(comanda);
	}
	
	public ArrayList<ComandaProdusOnline> plateste(){
		return this.produse;
	}
	
	//functii specifice memento
	public MementoCosCumparaturi salvareCos(){
		return new MementoCosCumparaturi(
				(ArrayList<ComandaProdusOnline>)produse.clone());
	}
	
	public void incarcaSalvare(MementoCosCumparaturi memento){
		this.produse = null;
		this.produse = 
				(ArrayList<ComandaProdusOnline>)memento.getState().clone();
	}
	
}
