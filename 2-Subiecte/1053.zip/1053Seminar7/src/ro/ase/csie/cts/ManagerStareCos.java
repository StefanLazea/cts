package ro.ase.csie.cts;

import java.util.ArrayList;

//Care-taker din memento

public class ManagerStareCos {
	private ArrayList<MementoCosCumparaturi> salvari = new ArrayList<>();
	
	public void addMemento(MementoCosCumparaturi salvare){
		salvari.add(salvare);
	}
	
	public MementoCosCumparaturi getLastMemento(){
		if(salvari.size()>0){
			MementoCosCumparaturi salvare = salvari.get(salvari.size()-1);
			salvari.remove(salvare);
			return salvare;
		}
		else
			return null;
	}
	
	public MementoCosCumparaturi getMemento(long timestamp){
		MementoCosCumparaturi salvare = null;
		
		if(salvari.size()>0){
			for(MementoCosCumparaturi memento : salvari)
				if(timestamp == memento.timestampSalvare)
					salvare = memento;
			salvari.remove(salvare);
		}
		return salvare;
	}
	
}
