package ro.ase.csie.cts;

import java.util.ArrayList;

import javax.print.attribute.standard.DateTimeAtCompleted;

public class MementoCosCumparaturi {
	//starea originator
	private ArrayList<ComandaProdusOnline> comenzi;
	//timestamp
	long timestampSalvare;
	
	public MementoCosCumparaturi(
			ArrayList<ComandaProdusOnline> comenzi){
		this.timestampSalvare = System.currentTimeMillis();
		this.comenzi = comenzi;
		
	}
	
	public ArrayList<ComandaProdusOnline> getState(){
		return this.comenzi;
	}
}
