package ro.ase.csie.cts;

public class ServiciuLivrareComenzi {
	public static ServiciuLivrareComenzi self = null;
	
	private ServiciuLivrareComenzi(){
		
	}
	
	public static ServiciuLivrareComenzi getServiciu(){
		if(self==null)
			self = new ServiciuLivrareComenzi();
		return self;
	}
	
	public void proceseazaComandaStoc(
			ComandaProdusStoc comanda){
		System.out.println(
				"Comanda cu produsul "+comanda.produs+"va fi livrata de pe stoc");
	}
	
	public void proceseazaComandaFurnizor(
			ComandaProdusFunizor comanda){
		System.out.println(
				"Furnizorul "+comanda.furnizor+
				" va fi contactat pentru a livra produsul "+comanda.produs);
	}
}
