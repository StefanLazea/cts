package ro.ase.csie.cts;

import java.util.ArrayList;

public class WebSite {

	public static void main(String[] args) {
		CosCumparaturi sesiuneUtilizator = 
				new CosCumparaturi("Gigel");
		
		//initializare memento
		ManagerStareCos manager = new ManagerStareCos();
		
		
		ComandaProdusStoc comanda1 = 
				new ComandaProdusStoc();
		comanda1.furnizor = "Emag";
		comanda1.produs = "Laptop";
		sesiuneUtilizator.adaugaProdus(comanda1);
		
		ComandaProdusFunizor comanda2 = 
				new ComandaProdusFunizor();
		comanda2.furnizor = "Flanco";
		comanda2.produs = "Masina de spalat";
		sesiuneUtilizator.adaugaProdus(comanda2);
		
		//snapshot cos cumparaturi
		manager.addMemento(sesiuneUtilizator.salvareCos());
		
		ComandaProdusFunizor comanda3 = 
				new ComandaProdusFunizor();
		comanda3.furnizor = "Flanco";
		comanda3.produs = "Aer conditionat";
		sesiuneUtilizator.adaugaProdus(comanda3);
		
		//restaurare stare Cos cumparaturi
		sesiuneUtilizator.incarcaSalvare(manager.getLastMemento());
		
		//receiver
		ServiciuLivrareComenzi srv = 
				ServiciuLivrareComenzi.getServiciu();
		
		//invoker-ul termina treaba si doreste procesarea comenzilor
		
		ArrayList<ComandaProdusOnline> comenzi = 
				sesiuneUtilizator.plateste();
		
		//alte prelucrari sau utilizare coada de comenzi gestionata de server
		
		//procesare
		for(ComandaProdusOnline comanda : comenzi)
			comanda.proceseaza(srv);
		comenzi.clear();
		
		
	}

}
