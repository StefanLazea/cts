package v1_eagerinitialization;

public class Program {

	public static void main(String[] args) {
		AgentieEagerInitialization agentie1=AgentieEagerInitialization.getInstanta("Agentie", 1000, 20);
		AgentieEagerInitialization agentie2=AgentieEagerInitialization.getInstanta("Agentie noua", 0, 0);
		
		System.out.println(agentie1.toString());
		System.out.println(agentie2.toString());
		
	}
}
