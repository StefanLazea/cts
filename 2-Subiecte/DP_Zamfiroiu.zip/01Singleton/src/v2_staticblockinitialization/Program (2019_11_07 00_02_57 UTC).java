package v2_staticblockinitialization;

public class Program {

	public static void main(String[] args) {
		AgentieStaticBlock agentie1=AgentieStaticBlock.getInstanta("Agentie", 1000, 20);
		AgentieStaticBlock agentie2=AgentieStaticBlock.getInstanta("Agentie noua", 0, 0);
		
		System.out.println(agentie1.toString());
		System.out.println(agentie2.toString());
		
	}

}
