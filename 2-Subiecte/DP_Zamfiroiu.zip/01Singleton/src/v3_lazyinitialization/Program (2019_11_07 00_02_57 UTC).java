package v3_lazyinitialization;

public class Program {

	public static void main(String[] args) {
		AgentieLazyInitilization agentie1=AgentieLazyInitilization.getInstanta("Agentie", 1000, 20);
		AgentieLazyInitilization agentie2=AgentieLazyInitilization.getInstanta("Agentie noua", 0, 0);
		
		System.out.println(agentie1.toString());
		System.out.println(agentie2.toString());
		
	}

}
