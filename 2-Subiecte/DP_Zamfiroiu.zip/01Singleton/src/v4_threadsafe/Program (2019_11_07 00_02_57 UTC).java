package v4_threadsafe;

public class Program {

	public static void main(String[] args) {
		AgentieThreadSafe agentie1=AgentieThreadSafe.getInstanta("Agentie", 1000, 20);
		AgentieThreadSafe agentie2=AgentieThreadSafe.getInstanta("Agentie noua", 0, 0);
		
		System.out.println(agentie1.toString());
		System.out.println(agentie2.toString());		
	}

}
