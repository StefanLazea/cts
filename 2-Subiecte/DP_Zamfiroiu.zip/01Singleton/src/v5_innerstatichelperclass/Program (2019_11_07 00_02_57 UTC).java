package v5_innerstatichelperclass;

public class Program {

	public static void main(String[] args) {
		AgentieInnerClass agentie1=AgentieInnerClass.getInstanta("Agentie", 1000, 20);
		AgentieInnerClass agentie2=AgentieInnerClass.getInstanta("Agentie noua", 0, 0);
		
		System.out.println(agentie1.toString());
		System.out.println(agentie2.toString());		
	}

}
