package v6_enum;

public class Program {

	public static void main(String[] args) {
		AgentieEnum agentie1=AgentieEnum.instanta;
		AgentieEnum agentie2=AgentieEnum.instanta;
		
		System.out.println(agentie1.toString());
		System.out.println(agentie2.toString());		
	}

}
