package v8_registry_of_singletons;

public class PachetTransport implements PachetTuristic {

	@Override
	public void descriere() {
		System.out.println("Acest pachet inlude doar transport");
	}

}
