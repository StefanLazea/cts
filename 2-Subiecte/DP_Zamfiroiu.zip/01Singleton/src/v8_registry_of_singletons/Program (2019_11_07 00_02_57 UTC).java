package v8_registry_of_singletons;

public class Program {

	public static void main(String[] args) {
		PachetCazare cazare=new PachetCazare();
		PachetTransport transport=new PachetTransport();
		
		try {
			RegistryPachete.register("Cazare", cazare);
			RegistryPachete.register("Transport", transport);
			
			RegistryPachete.getPachet("Cazare").descriere();
			RegistryPachete.getPachet("Transport").descriere();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
