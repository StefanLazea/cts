package contbancar;

public interface IBuilder {
	ContBancar build();
}
