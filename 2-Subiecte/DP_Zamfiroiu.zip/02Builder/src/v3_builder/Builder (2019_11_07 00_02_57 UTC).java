package v3_builder;

public interface Builder {
    PachetCalatorie build();
}
