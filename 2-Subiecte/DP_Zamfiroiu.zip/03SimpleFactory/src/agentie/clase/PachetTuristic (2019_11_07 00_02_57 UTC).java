package agentie.clase;

public interface PachetTuristic {
	void descriere();
}


