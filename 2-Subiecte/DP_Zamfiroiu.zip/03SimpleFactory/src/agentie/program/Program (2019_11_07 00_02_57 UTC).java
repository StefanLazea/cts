package agentie.program;

import agentie.clase.AgentieFactory;
import agentie.clase.PachetTuristic;
import agentie.clase.TipPachet;

public class Program {

	public static void main(String[] args) {
		AgentieFactory agentieFactory = new AgentieFactory();
		PachetTuristic pachetTuristic = null;
		try {
			pachetTuristic = agentieFactory.createPachet(TipPachet.pachetTransport);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		pachetTuristic.descriere();
	}

}


