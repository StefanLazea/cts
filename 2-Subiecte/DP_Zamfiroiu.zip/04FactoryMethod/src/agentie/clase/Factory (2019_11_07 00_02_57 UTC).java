package agentie.clase;

public interface Factory {
	PachetTuristic createPachet();
}
