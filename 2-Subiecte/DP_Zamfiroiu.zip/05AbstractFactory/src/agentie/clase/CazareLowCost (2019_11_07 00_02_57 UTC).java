package agentie.clase;

public class CazareLowCost implements PachetCazare {

	@Override
	public void descriere() {
		System.out.println("Ati ales o cazare Low cost");
	}

}
