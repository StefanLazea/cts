package agentie.clase;

public class CazarePremium implements PachetCazare {

	@Override
	public void descriere() {
		System.out.println("Ati ales o cazare Premium");
	}

}
