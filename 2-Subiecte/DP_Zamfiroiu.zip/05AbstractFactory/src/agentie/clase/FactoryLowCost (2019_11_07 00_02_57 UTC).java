package agentie.clase;

public class FactoryLowCost implements Factory {

	@Override
	public PachetCazare createPachetCazare() {
		return new CazareLowCost();
	}

	@Override
	public PachetTransport createPachetTransport() {
		return new TransportLowCost();
	}

}
