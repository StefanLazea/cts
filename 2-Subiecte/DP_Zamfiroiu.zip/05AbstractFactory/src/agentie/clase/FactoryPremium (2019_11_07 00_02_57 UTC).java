package agentie.clase;

public class FactoryPremium implements Factory {

	@Override
	public PachetCazare createPachetCazare() {
		return new CazarePremium();
	}

	@Override
	public PachetTransport createPachetTransport() {
		return new TransportPremium();
	}

}
