package agentie.clase;

public interface PachetTransport {
	void descriere();
}
