package agentie.clase;

public class TransportLowCost implements PachetTransport {

	@Override
	public void descriere() {
		System.out.println("Ati ales transport Low cost");
	}

}
