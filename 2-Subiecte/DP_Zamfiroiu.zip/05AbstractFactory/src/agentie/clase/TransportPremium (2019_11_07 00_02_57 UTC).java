package agentie.clase;

public class TransportPremium implements PachetTransport {

	@Override
	public void descriere() {
		System.out.println("Ati ales transport Premium");
	}

}
