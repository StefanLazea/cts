package agentie.program;

import agentie.clase.Factory;
import agentie.clase.FactoryLowCost;
import agentie.clase.FactoryPremium;
import agentie.clase.PachetCazare;
import agentie.clase.PachetTransport;

public class Program {	
	PachetCazare obtineCazare(Factory fabrica){
		return fabrica.createPachetCazare();
	}

	public static void main(String[] args) {
		Factory fabricaAgentie=new FactoryPremium();
		PachetTransport cazare= fabricaAgentie.createPachetTransport();
		cazare.descriere();
	}
}
