package agentie.adapterobiecte.program;

import agentie.adapterobiecte.clase.PachetCazare;
import agentie.adapterobiecte.clase.PachetMasinaInchiriata;
import agentie.adapterobiecte.clase.PachetTuristic;
import agentie.adapterobiecte.inchirieremasini.Masina;
import agentie.adapterobiecte.inchirieremasini.MasinaInchiriata;

public class Program {

	private static void printeazaRezervare(PachetTuristic pachetTuristic) {
		System.out.print("Pentru client: ");
		pachetTuristic.descriere();
		System.out.print("Pentru Operator: ");
		pachetTuristic.rezervaPachet();
	}

	public static void main(String[] args) {
		
		PachetCazare cazare=new PachetCazare();
		printeazaRezervare(cazare);
		
		MasinaInchiriata masina=new MasinaInchiriata(new Masina("BMW", 2000));
		PachetMasinaInchiriata pachet=new PachetMasinaInchiriata(masina);
		printeazaRezervare(pachet);
	}
}
