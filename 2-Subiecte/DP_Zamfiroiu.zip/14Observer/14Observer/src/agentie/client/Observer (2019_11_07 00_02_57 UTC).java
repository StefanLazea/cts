package agentie.client;

public interface Observer {
	public void receptionareMesaj(String mesaj);
}
