package agentie.clase;

public interface Stare {

	void doAction(Rezervare rezervare);
}
