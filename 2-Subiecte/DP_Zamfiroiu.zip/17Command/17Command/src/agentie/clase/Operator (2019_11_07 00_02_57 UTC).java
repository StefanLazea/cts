package agentie.clase;

public class Operator {

	public void invoca(Command comanda){
		comanda.executa();
	}
}
