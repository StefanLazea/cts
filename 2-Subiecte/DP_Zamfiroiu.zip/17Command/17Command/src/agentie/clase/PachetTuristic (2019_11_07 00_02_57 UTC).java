package agentie.clase;

public interface PachetTuristic {
	void vanzare();
	void rezerva();
}
