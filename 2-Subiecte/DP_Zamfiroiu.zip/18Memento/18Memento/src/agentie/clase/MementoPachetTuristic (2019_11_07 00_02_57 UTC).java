package agentie.clase;

public class MementoPachetTuristic {
	double pretPachet;

	public MementoPachetTuristic(double pretPachet) {
		super();
		this.pretPachet = pretPachet;
	}

	public double getPretPachet() {
		return pretPachet;
	}	
}
