package cts.exames.s4.pattern1;

public class ObiectivTuristic {
	private String denumireObiectiv;
	private float pretBiletAdult;
	private float pretBiletElev;
	
	public ObiectivTuristic(String denumireObiectiv, float pretBiletAdult,
			float pretBiletElev) {
		this.denumireObiectiv = denumireObiectiv;
		this.pretBiletAdult = pretBiletAdult;
		this.pretBiletElev = pretBiletElev;
	}
	
	
}
