package cts.exames.s4.pattern1;

public class Primarie {
	private String denumire;

	public Primarie(String denumire) {
		this.denumire = denumire;
	}
	
}
