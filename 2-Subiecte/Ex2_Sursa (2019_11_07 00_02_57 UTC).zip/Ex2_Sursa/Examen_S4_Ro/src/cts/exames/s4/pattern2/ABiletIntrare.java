package cts.exames.s4.pattern2;

public abstract class ABiletIntrare {
	protected float pret;
	
	abstract float getPret();

}
