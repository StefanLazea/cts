package cts.exames.s4.pattern2;

public class BiletIntrare extends ABiletIntrare{
	private boolean ghid;
	
	@Override
	float getPret() {
		if(ghid == true)
			return this.pret * 0.5f;
		else
			return this.pret;
	}

}
