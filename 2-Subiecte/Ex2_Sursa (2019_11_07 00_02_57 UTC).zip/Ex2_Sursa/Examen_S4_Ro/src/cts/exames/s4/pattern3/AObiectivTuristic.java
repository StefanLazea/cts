package cts.exames.s4.pattern3;

public abstract class AObiectivTuristic {
	private String denumire;
	private String adresa;
	
	public abstract void getInfo();
}
