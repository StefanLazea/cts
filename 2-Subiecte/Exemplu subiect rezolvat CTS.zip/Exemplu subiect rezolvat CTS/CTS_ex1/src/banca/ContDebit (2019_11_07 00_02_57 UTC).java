/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banca;

/**
 *
 * @author mandu
 */
public class ContDebit implements ContBancar{
    private double valoare = 0;
    
    
    @Override
    public void transferaSuma(ContBancar contBancarDestinatie, double suma) {
        contBancarDestinatie.depuneSuma(suma);
        valoare -= suma;
    }

    @Override
    public void depuneSuma(double suma) {
       valoare +=suma;
    }

    @Override
    public String toString() {
        return "ContDebit{" + "valoare=" + valoare + '}';
    }
    
    
    
}
