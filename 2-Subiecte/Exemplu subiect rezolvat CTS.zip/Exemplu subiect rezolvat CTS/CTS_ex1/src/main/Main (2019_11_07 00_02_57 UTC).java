/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import banca.ContCredit;
import banca.ContDebit;
import banca.ContBancar;
import bancaFuziune.DebitAccount;
import adapter.DebitAccountAdapter;
import factory.ContFactory;

/**
 *
 * @author mandu
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ContFactory cf = ContFactory.getInstance();

        ContCredit cc = (ContCredit) cf.creazaCont("contCredit");

        System.out.println(cc);
        cc.depuneSuma(100);
        System.out.println(cc);

        ContDebit cd = (ContDebit) cf.creazaCont("contDebit");
        System.out.println(cd);
        cc.transferaSuma(cd, 50);
        System.out.println(cd);
        System.out.println(cc);

        ContBancar cb1 = new DebitAccountAdapter(new DebitAccount());
        System.out.println(cb1);
        cc.transferaSuma(cb1, 50);
        System.out.println(cc);
        System.out.println(cb1);

    }

}
