package socea.eduard.g1074;

public class AdresaWeb {
	String url;
	int timpIncarcare;
	
	public AdresaWeb(String url, int timpIncarcare) throws ExceptieWeb{
            super();
            if(timpIncarcare <= 0) throw new ExceptieWeb("Timpul de incarcare nu este valid");
            this.url = url;
            this.timpIncarcare = timpIncarcare;
	}
	public String getUrl() {
            return url;
	}
	public void setUrl(String url) {
            this.url = url;
	}
	public int getTimpIncarcare() {
            return timpIncarcare;
	}
	public void setTimpIncarcare(int timpIncarcare) throws ExceptieWeb{
            if(timpIncarcare <= 0) throw new ExceptieWeb("Timpul de incarcare nu este valid");
            this.timpIncarcare = timpIncarcare;
	}
	
	public String getPageRanking(ISearchEngine motorCautare){
            if(motorCautare.getRating()<0)
                return "Pagina vulnerabila";
            else
                return "Pagina ok";
	}
}
