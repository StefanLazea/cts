package socea.eduard.g1074;

import java.util.ArrayList;

public class Browser {
	String denumire;
	int versiune;
	ArrayList<AdresaWeb> taburiDeschise;

	public Browser() {
		super();
		denumire = "Default";
		taburiDeschise = new ArrayList<>();
	}
	
	public void deschidePagina(AdresaWeb adresa){
		taburiDeschise.add(adresa);
	}
	
	public int timpTotalIncarcare(){
		int suma = 0;
		for(AdresaWeb pagina : taburiDeschise)
			suma+=pagina.getTimpIncarcare();
		return suma;
	}

	public String getDenumire() {
		return denumire;
	}

	public void setDenumire(String versiune) {
		this.denumire = denumire;
	}

	public int getVersiune() {
		return versiune;
	}

	public void setVersiune(int versiune) {
		this.versiune = versiune;
	}
        
        public ArrayList<Integer> getListaTimpiIncarcare(){
            ArrayList<Integer> listaTimpi = new ArrayList<Integer>();
            for(AdresaWeb pagina: this.taburiDeschise){
                listaTimpi.add(pagina.getTimpIncarcare());
            }
            return listaTimpi;
        }
	
	
	
	
	
	
}
