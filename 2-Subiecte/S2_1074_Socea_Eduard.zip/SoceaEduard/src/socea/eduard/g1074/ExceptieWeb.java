package socea.eduard.g1074;

public class ExceptieWeb extends Exception{
	public ExceptieWeb(String mesaj){
		super(mesaj);
	}
}
