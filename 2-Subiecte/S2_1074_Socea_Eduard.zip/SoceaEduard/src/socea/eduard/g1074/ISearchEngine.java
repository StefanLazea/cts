package socea.eduard.g1074;

public interface ISearchEngine {
	public int getRating();
}
