/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package socea.eduard.g1074.Pattern;

import socea.eduard.g1074.Browser;

/**
 *
 * @author stud
 */
public abstract class Notificator {
    
   private Notificator urmatorulNotificator;
   
   public Notificator getUrmatorulNotificator() {
        return urmatorulNotificator;
    }
        
    public void setUrmatorulNotificator(Notificator notificator){
            this.urmatorulNotificator = notificator;
    }
	
    public abstract void notifica(Browser browser);
    
}
