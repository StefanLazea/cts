/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package socea.eduard.g1074.Pattern;

import socea.eduard.g1074.Browser;

/**
 *
 * @author stud
 */
public class NotificatorAds extends Notificator{
    @Override
    public void notifica(Browser browser) {
        System.out.println("Elimina Adds");
        super.getUrmatorulNotificator().notifica(browser);
    }
}
