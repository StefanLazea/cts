/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package socea.eduard.g1074;

import java.util.ArrayList;
import socea.eduard.g1074.Pattern.Notificator;
import socea.eduard.g1074.Pattern.NotificatorAds;
import socea.eduard.g1074.Pattern.NotificatorDescarcare;
import socea.eduard.g1074.Pattern.NotificatorParental;

/**
 *
 * @author stud
 */
public class SoceaEduard {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ExceptieWeb {
        ArrayList<Notificator> lista = new ArrayList<Notificator>();
        Notificator notificatorParental = new NotificatorParental();
        Notificator notificatorDescarare = new NotificatorDescarcare();
        Notificator notificatorAds = new NotificatorAds();
        
        notificatorAds.setUrmatorulNotificator(notificatorDescarare);
        notificatorDescarare.setUrmatorulNotificator(notificatorParental);
        
        Browser browser1 = new Browser();
        browser1.deschidePagina(new AdresaWeb("https://www.google.com", 20));
        browser1.deschidePagina(new AdresaWeb("https://www.amazon.com", 50));
        
        notificatorAds.notifica(browser1);
    }
    
}
