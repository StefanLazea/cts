/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package socea.eduard.g1074.testScripts;

import junit.framework.TestCase;
import socea.eduard.g1074.AdresaWeb;
import socea.eduard.g1074.ExceptieWeb;

public class TestCase_ConstructorAdresaWeb extends TestCase{

    public TestCase_ConstructorAdresaWeb(String name) {
        super(name);
    }

    @Override
    protected void tearDown() throws Exception {
        super.tearDown(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    protected void setUp() throws Exception {
        super.setUp(); //To change body of generated methods, choose Tools | Templates.
    }
    
    public void testRightConstructor() throws Exception{
        String expectedUrl = "https://www.google.com";
        int expectedTimpIncarcare = 10;
        AdresaWeb adresaWeb = new AdresaWeb(expectedUrl, expectedTimpIncarcare);
        assertEquals(expectedUrl, adresaWeb.getUrl());
        assertEquals(expectedTimpIncarcare, adresaWeb.getTimpIncarcare());
    }
    
    public void testExceptionConstructor() throws Exception{
        String url = "https://www.google.com";
        int timpIncarcare =  0;
        try{
            AdresaWeb adresaWeb = new AdresaWeb(url, timpIncarcare);
            fail("Nu se genereaza exceptie");
        }catch(ExceptieWeb e){
            assertTrue(true);
        }catch(Exception e){
            fail("Se genereaza alta exceptie");
        }
    }
    
    public void testExistanceConstructor() throws Exception{
        AdresaWeb adresaWeb = new AdresaWeb("https://www.google.com",20);
        assertNotNull(adresaWeb);
    }

    public void testPerformanceConstructor() throws Exception{
        long t1 = System.currentTimeMillis();
        AdresaWeb adresaWeb = new AdresaWeb("https://www.google.com",20);
        long t2 = System.currentTimeMillis();
        if(t1 - t2 > 1000){
            fail("Constructorul dureaza prea mult");
        }else{
            assertTrue(true);
        }
    }
    
   
}
