/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package socea.eduard.g1074.testScripts;

import com.sun.jndi.toolkit.dir.SearchFilter;
import junit.framework.TestCase;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import socea.eduard.g1074.AdresaWeb;
import socea.eduard.g1074.ExceptieWeb;
import socea.eduard.g1074.SearchEngineMock;

/**
 *
 * @author stud
 */
public class TestCase_GetPageRating extends TestCase{

    public TestCase_GetPageRating(String name) {
        super(name);
    }

    @Override
    protected void tearDown() throws Exception {
        super.tearDown();
    }

    @Override
    protected void setUp() throws Exception {
        super.setUp();
    }
    
    public void testSearchEngineMock() throws ExceptieWeb{
        AdresaWeb adresaWeb = new AdresaWeb("https://www.youtube.com", 10);
        String expected = "Pagina ok";        
        String actual = adresaWeb.getPageRanking(new SearchEngineMock());
        assertEquals(expected,actual);
    } 
    
    
}
