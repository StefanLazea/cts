/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package socea.eduard.g1074.testScripts;

import junit.framework.TestCase;
import socea.eduard.g1074.AdresaWeb;
import socea.eduard.g1074.ExceptieWeb;


/**
 *
 * @author stud
 */
public class TestCase_SetTimpIncarcare extends TestCase {

    private AdresaWeb adresaWeb;
    
    public TestCase_SetTimpIncarcare(String name) throws Exception {
        super(name);
        adresaWeb = new AdresaWeb("https://www.google.com", 10);
    }

    @Override
    protected void tearDown() throws Exception {
        super.tearDown(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    protected void setUp() throws Exception {
        super.setUp(); //To change body of generated methods, choose Tools | Templates.
    }
    
    public void testRightSetTimpIncarcare() throws Exception{
        int expectedTimpIncarcare = 50;
        adresaWeb.setTimpIncarcare(expectedTimpIncarcare);
        assertEquals(expectedTimpIncarcare,adresaWeb.getTimpIncarcare());
    }
    
    public void testExceptionSetTimpIncarcare() throws Exception{
        try{
            adresaWeb.setTimpIncarcare(0);
            fail("Nu se genereaza exceptie");
        } catch(ExceptieWeb e){
            assertTrue(true);
        }catch(Exception e){
            fail("Se genereaza alta exceptie");
        }
    }
    
    public void testExistenceSetTimpIncarcare() throws Exception{
        adresaWeb.setTimpIncarcare(50);
        assertNotNull(adresaWeb.getTimpIncarcare());
    }
    
    public void testLowBounderySetTimpIncarcare() throws Exception{
        int lowLimitBoundery = 1;
        adresaWeb.setTimpIncarcare(lowLimitBoundery);
        assertEquals(lowLimitBoundery, adresaWeb.getTimpIncarcare());
    }
    
}
