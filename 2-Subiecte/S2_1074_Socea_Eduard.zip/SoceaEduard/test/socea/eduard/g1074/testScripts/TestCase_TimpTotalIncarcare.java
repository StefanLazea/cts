/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package socea.eduard.g1074.testScripts;

import java.util.ArrayList;
import java.util.stream.IntStream;
import junit.framework.TestCase;
import socea.eduard.g1074.AdresaWeb;
import socea.eduard.g1074.Browser;
import socea.eduard.g1074.ExceptieWeb;

/**
 *
 * @author stud
 */
public class TestCase_TimpTotalIncarcare extends TestCase{

    public TestCase_TimpTotalIncarcare(String name) {
        super(name);
    }

    @Override
    protected void tearDown() throws Exception {
        super.tearDown(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    protected void setUp() throws Exception {
        super.setUp(); //To change body of generated methods, choose Tools | Templates.
    }
   
    public void testInverseTimpTotalIncarcare() throws Exception{
        Browser browser1 = new Browser();
        browser1.deschidePagina(new AdresaWeb("https://www.google.com", 20));
        browser1.deschidePagina(new AdresaWeb("https://www.amazon.com", 50));
    
        Browser browser2 = new Browser();
        browser2.deschidePagina(new AdresaWeb("https://www.youtube.com", 40));
        browser2.deschidePagina(new AdresaWeb("https://www.acs.ase.ro", 50));

        assertNotSame(browser1.timpTotalIncarcare(), browser2.timpTotalIncarcare());
    }
    
    public void testCrossCheckTimpTotalIncarcare() throws Exception{
        Browser browser = new Browser();
        browser.deschidePagina(new AdresaWeb("https://www.google.com", 20));
        browser.deschidePagina(new AdresaWeb("https://www.amazon.com", 50));
        browser.deschidePagina(new AdresaWeb("https://www.youtube.com", 40));

        ArrayList<Integer> listaTimpi = browser.getListaTimpiIncarcare();
        int expectedSum = listaTimpi.stream().mapToInt(Integer::intValue).sum();
        
        assertEquals(expectedSum, browser.timpTotalIncarcare());
    }
    
}
