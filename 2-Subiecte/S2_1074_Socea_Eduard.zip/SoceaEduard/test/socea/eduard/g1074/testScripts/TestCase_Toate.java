/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package socea.eduard.g1074.testScripts;

import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.junit.Test;

/**
 *
 * @author stud
 */
public class TestCase_Toate extends TestCase {

    public TestCase_Toate(String name) {
        super(name);
    }

    @Override
    protected void tearDown() throws Exception {
        super.tearDown();
    }

    @Override
    protected void setUp() throws Exception {
        super.setUp();
    }
    
    public static TestSuite suite(){
        TestSuite colectie = new TestSuite();
        colectie.addTestSuite(TestCase_SetTimpIncarcare.class);
        colectie.addTest(new TestCase_ConstructorAdresaWeb("testRightConstructor"));
        colectie.addTest(new TestCase_ConstructorAdresaWeb("testExceptionConstructor"));
        return colectie;
    }
    
}
