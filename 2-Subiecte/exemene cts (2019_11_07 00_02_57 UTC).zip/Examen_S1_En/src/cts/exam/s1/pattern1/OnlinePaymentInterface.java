package cts.exam.s1.pattern1;

public interface OnlinePaymentInterface {
	public abstract void onlinePay();
}
