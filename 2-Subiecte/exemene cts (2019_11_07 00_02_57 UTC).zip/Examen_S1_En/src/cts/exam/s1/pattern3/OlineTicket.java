package cts.exam.s1.pattern3;

public abstract class OlineTicket {
	String eventName;
	int ticketNumber;
	
	public OlineTicket(String eventName, int ticketNumber) {
		super();
		this.eventName = eventName;
		this.ticketNumber = ticketNumber;
	}
	
	public abstract String getType();

	public void displayTicket(){
		System.out.println(String.format("It's a {0} type ticket for {1} with a price of {2}", this.getType(), eventName, ticketNumber));
	}
}
