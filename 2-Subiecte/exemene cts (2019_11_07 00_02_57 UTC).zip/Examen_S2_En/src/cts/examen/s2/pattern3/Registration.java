package cts.examen.s2.pattern3;

//initial proposel
//the class can be changed 

public class Registration {
	
	// must be the 1st step
	public void askName(){
		
	}
	
	// must be the 3rd step
	public void askMedicalRecords(){
		
	}
	
	// must be the 5th step
	public void askEmail(){
		
	}
	
	// must be the 2nd step
	public void askSocialNumber(){
		
	}
	
	// must be the 4th step
	public void askCreditCard(){
		
	}
	

}
