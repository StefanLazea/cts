

public interface IClient {
	String getName();
}
