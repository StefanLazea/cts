

public interface IVehicle {
	double getWeight();
	String getModel();
	
}
