
public interface InspectionProcessingInterface {
	public void scheduleAnInspection(IVehicle vechicle);
}
