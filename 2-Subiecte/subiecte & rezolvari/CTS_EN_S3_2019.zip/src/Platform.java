import java.util.ArrayList;

public class Platform {

	private int platformNo;
	private int daySinceLastInspection;
	private ArrayList<Integer> piecesCost;

	public Platform(int platformNo, int noDays) {
		this.platformNo = platformNo;
		this.daySinceLastInspection = noDays;
		piecesCost = new ArrayList<>();
	}
	
	public ArrayList<Integer> getPiecesCost() {
		return piecesCost;
	}

	public void setPiecesCost(ArrayList<Integer> piecesCost) {
		this.piecesCost = piecesCost;
	}

	public void setNoDays(int noDays) {
		this.daySinceLastInspection = noDays;
	}

	public boolean isInspectionNecessary() {
		return this.daySinceLastInspection > 365;
	}
	
	public int totalCost() {
		int total = 10;
		for(int cost : piecesCost)
			total += cost;
		return total;
	}
	

	public int getVehicleTransportCost(IVehicle vehicle) {
		if(vehicle.getWeight() > 1000)
			return 150;
		else
			return 90;
	}

}
