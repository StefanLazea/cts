package cts.exam.s1.pattern3;

public enum TipTicket {
	CONCERT,EVENIMENT,MUZEU
}
