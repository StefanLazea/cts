package s3.g1077.constantin.doinita.command;

import java.util.ArrayList;
import java.util.List;

import s3.g1077.constantin.doinita.proxy.InspectionProcessingInterface;
import s3.g1077.constantin.doinita.proxy.InspectionScheduler;
import s3.g1077.constantin.doinita.template.IVehicle;

public class ComandScheduler implements ICommand{
	private List<InspectionProcessingInterface> inspections;
	public ComandScheduler(List<InspectionProcessingInterface> inspections) {
		super();
		this.inspections = inspections;
	}
	@Override
	public void execute(IVehicle vehicle) {
		for(InspectionProcessingInterface inspection:inspections) {
			inspection.scheduleAnInspection(vehicle);
		}
		
		
	}

}
