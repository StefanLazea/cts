package s3.g1077.constantin.doinita.command;

import s3.g1077.constantin.doinita.template.IVehicle;

public interface ICommand {
	public void execute(IVehicle vehicle);
}
