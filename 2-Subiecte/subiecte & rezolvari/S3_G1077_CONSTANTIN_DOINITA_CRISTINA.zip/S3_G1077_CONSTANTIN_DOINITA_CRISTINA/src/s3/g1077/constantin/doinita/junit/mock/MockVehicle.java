package s3.g1077.constantin.doinita.junit.mock;

import s3.g1077.constantin.doinita.template.IVehicle;

public class MockVehicle implements IVehicle {
	private double weight;
	private String model;
	
	public MockVehicle(double weight, String model) {
		super();
		this.weight = weight;
		this.model = model;
	}

	@Override
	public double getWeight() {
		return weight;
	}

	@Override
	public String getModel() {
		return model;
	}

}
