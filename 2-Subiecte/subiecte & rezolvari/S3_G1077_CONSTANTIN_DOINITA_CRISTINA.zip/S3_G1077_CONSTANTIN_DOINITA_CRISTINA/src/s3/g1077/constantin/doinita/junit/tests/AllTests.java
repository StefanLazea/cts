package s3.g1077.constantin.doinita.junit.tests;

import org.junit.experimental.categories.Categories.IncludeCategory;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@IncludeCategory(CategoryImportant.class)
@RunWith(Suite.class)
@SuiteClasses({ TestCaseGetVehicleTransportCost.class, TestCaseIsInspectionNecessary.class, TestCaseSetNoDays.class,
		TestCaseTotalCost.class })
public class AllTests {

}
