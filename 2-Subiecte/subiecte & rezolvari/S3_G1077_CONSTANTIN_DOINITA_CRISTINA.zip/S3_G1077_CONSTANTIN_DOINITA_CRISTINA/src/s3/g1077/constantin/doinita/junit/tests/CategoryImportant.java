package s3.g1077.constantin.doinita.junit.tests;

public class CategoryImportant {

}
