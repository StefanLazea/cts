package s3.g1077.constantin.doinita.junit.tests;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.experimental.categories.Category;

import com.sun.media.jfxmediaimpl.platform.Platform;

import s3.g1077.constantin.doinita.junit.mock.MockVehicle;
import s3.g1077.constantin.doinita.template.IVehicle;

public class TestCaseGetVehicleTransportCost {
	IVehicle mock;
	Platform platform;
	public void setUp() {
		mock = new MockVehicle(1500, "Dacia");
	}
	@Category(CategoryImportant.class)
	@Test
	public void testMock() {
		double expected = 150;
		
	}

}
