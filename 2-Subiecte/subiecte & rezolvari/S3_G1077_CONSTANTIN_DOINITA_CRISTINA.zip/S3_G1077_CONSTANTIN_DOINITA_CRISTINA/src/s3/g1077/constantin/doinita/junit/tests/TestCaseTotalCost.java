package s3.g1077.constantin.doinita.junit.tests;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestCaseTotalCost {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
