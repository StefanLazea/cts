package s3.g1077.constantin.doinita.main;

import java.util.ArrayList;
import java.util.List;

import s3.g1077.constantin.doinita.command.ComandScheduler;
import s3.g1077.constantin.doinita.command.ICommand;
import s3.g1077.constantin.doinita.proxy.InspectionProcessingInterface;
import s3.g1077.constantin.doinita.proxy.InspectionScheduler;
import s3.g1077.constantin.doinita.proxy.InspectionSchedulerProxy;
import s3.g1077.constantin.doinita.proxy.Vehicle;
import s3.g1077.constantin.doinita.template.AutoServiceA;
import s3.g1077.constantin.doinita.template.AutoServiceB;
import s3.g1077.constantin.doinita.template.AutoServiceInspection;
import s3.g1077.constantin.doinita.template.IVehicle;

public class Program {

	public static void main(String[] args) {
		
		AutoServiceInspection inspection = new AutoServiceB();
		inspection.makePeriodicInspection();
		AutoServiceInspection inspection2 = new AutoServiceA();
		inspection2.makePeriodicInspection();
		
		IVehicle vehicle = new Vehicle(450, "Dacia Logan");
		IVehicle vehicle2 = new Vehicle(900, "Tesla model S");
		InspectionProcessingInterface scheduler = new InspectionSchedulerProxy(new InspectionScheduler());
		scheduler.scheduleAnInspection(vehicle);
		scheduler.scheduleAnInspection(vehicle2);
		InspectionProcessingInterface scheduler2 = new InspectionSchedulerProxy(new InspectionScheduler());
		
		
		List<InspectionProcessingInterface> inspections = new ArrayList<InspectionProcessingInterface>();
		inspections.add(scheduler);
		inspections.add(scheduler2);
		ICommand command = new ComandScheduler(inspections);
		command.execute(vehicle);

		
	}

}
