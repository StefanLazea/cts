package s3.g1077.constantin.doinita.proxy;

import s3.g1077.constantin.doinita.template.IVehicle;

public interface InspectionProcessingInterface {
	public void scheduleAnInspection(IVehicle vechicle);
}
