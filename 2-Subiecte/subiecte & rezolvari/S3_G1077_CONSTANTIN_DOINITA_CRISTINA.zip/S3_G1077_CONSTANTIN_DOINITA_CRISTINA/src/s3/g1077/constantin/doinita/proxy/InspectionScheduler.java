package s3.g1077.constantin.doinita.proxy;

import s3.g1077.constantin.doinita.template.IVehicle;

public class InspectionScheduler implements InspectionProcessingInterface{

	@Override
	public void scheduleAnInspection(IVehicle vechicle) {
		System.out.println("Scheduling an inspection for " + vechicle.getModel());
	}
	
	
	
}
