package s3.g1077.constantin.doinita.proxy;

import s3.g1077.constantin.doinita.template.IVehicle;

public class InspectionSchedulerProxy implements InspectionProcessingInterface {
	private InspectionScheduler scheduler;
	
	
	public InspectionSchedulerProxy(InspectionScheduler scheduler) {
		super();
		this.scheduler = scheduler;
	}


	@Override
	public void scheduleAnInspection(IVehicle vehicle) {
		if(vehicle.getWeight() <500) {
			scheduler.scheduleAnInspection(vehicle);
		}
		
	}
	
}
