package s3.g1077.constantin.doinita.proxy;

import s3.g1077.constantin.doinita.template.IVehicle;

public class Vehicle implements IVehicle{
	
	private double weight;
	private String model;

	public Vehicle(double weight, String model) {
		super();
		this.weight = weight;
		this.model = model;
	}

	@Override
	public double getWeight() {
		return this.weight;
	}
	
	@Override
	public String getModel() {
		// TODO Auto-generated method stub
		return this.model;
	}

}
