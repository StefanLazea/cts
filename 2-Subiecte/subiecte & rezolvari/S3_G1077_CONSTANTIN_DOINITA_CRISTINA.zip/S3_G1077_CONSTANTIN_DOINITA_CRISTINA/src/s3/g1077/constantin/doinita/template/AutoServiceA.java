package s3.g1077.constantin.doinita.template;

public class AutoServiceA extends AutoServiceInspection{

	@Override
	public void visualCheck(IVehicle vehicle) {
		System.out.println("visual check for AutoService A");
		
	}

	@Override
	public void exhaustCheck(IVehicle vehicle) {
		System.out.println("exhaus check for AutoService A");
		
	}

	@Override
	public void brakesChekc(IVehicle vehicle) {
		System.out.println("brakes check for Autoservice A");
		
	}

	@Override
	public void mechanicalPartsCheck(IVehicle vehicle) {
		System.out.println("mechanical check for Autoservice A");
		
	}

}
