package s3.g1077.constantin.doinita.template;

public abstract class AutoServiceInspection {
	IVehicle vehicle;
	public  abstract void  visualCheck(IVehicle vehicle);
	public abstract void exhaustCheck(IVehicle vehicle);
	public abstract void brakesChekc(IVehicle vehicle);
	public abstract void mechanicalPartsCheck(IVehicle vehicle);
	
	public final void makePeriodicInspection(){
		visualCheck( vehicle);
		exhaustCheck(vehicle);
		brakesChekc( vehicle);
		mechanicalPartsCheck(vehicle);
	}
	
}
