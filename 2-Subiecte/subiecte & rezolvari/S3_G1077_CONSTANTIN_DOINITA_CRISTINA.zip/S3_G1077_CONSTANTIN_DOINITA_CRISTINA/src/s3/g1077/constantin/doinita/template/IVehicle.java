package s3.g1077.constantin.doinita.template;

public interface IVehicle {
	double getWeight();
	String getModel();
	
}
