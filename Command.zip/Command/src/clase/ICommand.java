package clase;

public interface ICommand {
	void executa(String numePacient);
}
