package clase;

public class RaspunsNegativ extends Angajator {

	@Override
	public void angajare(Candidat candidat) {
		System.out.println("Ne pare rau! Profilul dvs nu corespunde companiei noastre.");
	}

}
