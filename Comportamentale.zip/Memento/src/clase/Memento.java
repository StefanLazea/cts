package clase;

public class Memento {
	private int nrPacienti;

	public Memento(int nrPacienti) {
		super();
		this.nrPacienti = nrPacienti;
	}

	public int getNrPacienti() {
		return nrPacienti;
	}

}
