package clase;

public interface IStare {
	void schimbareStarea(Masa masa);
	void afisareStare(int nrMasa);
}
