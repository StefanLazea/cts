package clase;

public interface ModPlata {
	void plateste(String numePacient, float suma);
}
