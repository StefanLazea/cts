package clase;

public class Program {

	public static void main(String[] args) {
		Ospatar os = new Ospatar();
		os.asezarePersoanaLaMasa(1);
		
		Barman bar = new Barman();
		bar.asezarePersoanaLaMasa(2);
	}

}
