package clase;

public interface IBuilder {
	public Rezervare build();
}
