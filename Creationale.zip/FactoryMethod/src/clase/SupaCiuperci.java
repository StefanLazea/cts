package clase;

public class SupaCiuperci implements ISupa{

	@Override
	public void descirere() {
		// TODO Auto-generated method stub
		System.out.println("supa ciuperci");
	}

}
