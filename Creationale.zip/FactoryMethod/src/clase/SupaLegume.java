package clase;

public class SupaLegume implements ISupa{

	@Override
	public void descirere() {
		// TODO Auto-generated method stub
		System.out.println("supa legume");
	}
	
}
