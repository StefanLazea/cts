package clase;

public class SupaPui implements ISupa {

	@Override
	public void descirere() {
		// TODO Auto-generated method stub
		System.out.println("supa de pui");
	}

}
