package clase;

public class SupaVita implements ISupa{

	@Override
	public void descirere() {
		// TODO Auto-generated method stub
		System.out.println("supa vita");
	}

}
