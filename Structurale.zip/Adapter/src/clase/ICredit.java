package clase;

public interface ICredit {
	public void oferaCredit();
	public float rataLunara();
}
