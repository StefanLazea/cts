package clase;

public interface ICard {
	public void plataOnline();
	public void plataNormala();
}
