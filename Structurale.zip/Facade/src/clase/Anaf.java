package clase;

public class Anaf {
	public static boolean areDatorii(String cnp) {
		return cnp.charAt(12)%2==0;
	}
}
