package command.clase;

public interface ICommand {
	void execute();
	void unexecute();
}
