package teste.categorii;

public interface CategorieTestePersoaneNascuteDupa2000 {

}
