package teste.categorii;

public interface CategorieTestePersoaneNascuteInainte2000 {

}
