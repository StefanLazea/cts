package teste.categorii;

public interface CategorieTestePersoaneTinere {

}
